import pandas as pd
print("\n\nЗАДАНИЕ 1\n\n")
# хадани1
def get_books(a):
    df = pd.read_csv(a, sep='|')
    df['quantity'] = df['quantity'].astype(int)
    df['price'] = df['price'].astype(float)
    return df.values.tolist()
L = get_books("books.csv")
print(L)
print("\n\nЗАДАНИЕ 2\n\n")
# задние2
def filtered_books(b, s):
    df = pd.DataFrame(b, columns = ['isbn','title','author','quantity','price'])
    m = df[df['title'].str.contains(s, case=False)]
    df['titleAuthor'] = df['title']+ ',' + df['author']
    return df[['isbn','titleAuthor','quantity','price']].values.tolist()
p = filtered_books(L, "python")
print(p)
print("\n\nЗАДАНИЕ 3\n\n")
# задание3
def kortezh(c):
    df = pd.DataFrame(c, columns= ['isbn','titleAuthor','quantity','price'])
    df['general'] = df['quantity'] * df['price']
    return list(zip(df['isbn'], df['general']))
Ia_Ustal = kortezh(p)
print(Ia_Ustal)